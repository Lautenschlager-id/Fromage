lit install Lautenschlager-id/fromage
touch autoupdate