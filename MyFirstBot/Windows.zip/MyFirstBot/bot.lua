local api = require("fromage")
local client = api()

coroutine.wrap(function()
	print("Logging")
	client.connect("Username#0000", "password")

	if client.isConnected() then
		print("Logged")
		-- TODO
	end

	client.disconnect()
	os.execute("pause >nul")
end)()